const { createFilter } = require("odata-v4-sql")

const func = () => {
    const foo = "Name eq 'Ginny' and Animal eq 'Dog'"
    const filter = createFilter(foo);
    
    console.log(filter.from("Foo"));
}


exports.handler = func